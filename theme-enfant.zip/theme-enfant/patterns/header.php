<?php
/**
 * Title: header
 * Slug: theme-enfant/header
 * Categories: hidden
 * Inserter: no
 */
?>
<!-- wp:group {"className":"is-style-default","style":{"spacing":{"padding":{"top":"0px","bottom":"0px"},"margin":{"top":"0","bottom":"0px"}},"elements":{"link":{"color":{"text":"var:preset|color|base-3"}}},"border":{"radius":"0px"}},"backgroundColor":"base-3","textColor":"base-3","layout":{"type":"constrained"}} -->
<div class="wp-block-group is-style-default has-base-3-color has-base-3-background-color has-text-color has-background has-link-color" style="border-radius:0px;margin-top:0;margin-bottom:0px;padding-top:0px;padding-bottom:0px"><!-- wp:group {"align":"wide","style":{"border":{"radius":"0px"},"spacing":{"padding":{"top":"0px","bottom":"0px"}}},"layout":{"type":"constrained","justifyContent":"left","wideSize":"500px"}} -->
<div class="wp-block-group alignwide" style="border-radius:0px;padding-top:0px;padding-bottom:0px"><!-- wp:yoast-seo/breadcrumbs /-->

<!-- wp:group {"style":{"spacing":{"blockGap":"0","padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30","left":"var:preset|spacing|30","right":"var:preset|spacing|30"}},"background":{"backgroundSize":"cover","backgroundPosition":"59% 38%","backgroundImage":{"url":"<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/images/Mask-group-1.png","id":76851,"source":"file","title":"Mask group (1)"}},"dimensions":{"minHeight":"350px"},"border":{"radius":{"topLeft":"20px","topRight":"20px","bottomLeft":"0px","bottomRight":"0px"}}},"backgroundColor":"contrast-2","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top","orientation":"vertical"}} -->
<div class="wp-block-group has-contrast-2-background-color has-background" style="border-top-left-radius:20px;border-top-right-radius:20px;border-bottom-left-radius:0px;border-bottom-right-radius:0px;min-height:350px;padding-top:var(--wp--preset--spacing--30);padding-right:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--30)"><!-- wp:post-title {"level":1} /--></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->